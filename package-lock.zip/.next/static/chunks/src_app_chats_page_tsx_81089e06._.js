(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_chats_page_tsx_81089e06._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_chats_page_tsx_81089e06._.js",
  "chunks": [
    "static/chunks/[root of the server]__abac7ec4._.js",
    "static/chunks/[next]_internal_font_google_94dac43d._.css"
  ],
  "source": "dynamic"
});
