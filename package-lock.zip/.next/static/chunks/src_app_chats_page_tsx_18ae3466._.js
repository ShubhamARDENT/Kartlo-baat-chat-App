(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_chats_page_tsx_18ae3466._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_chats_page_tsx_18ae3466._.js",
  "chunks": [
    "static/chunks/_0a02b1e8._.js"
  ],
  "source": "dynamic"
});
