(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_login_page_tsx_18ae3466._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_login_page_tsx_18ae3466._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5d4b37a9._.js",
    "static/chunks/_e78d2f83._.js"
  ],
  "source": "dynamic"
});
