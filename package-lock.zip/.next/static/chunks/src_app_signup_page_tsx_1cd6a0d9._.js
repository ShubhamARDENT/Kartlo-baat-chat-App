(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_signup_page_tsx_1cd6a0d9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_signup_page_tsx_1cd6a0d9._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b4f348ef._.js",
    "static/chunks/_a3c05f4a._.js"
  ],
  "source": "dynamic"
});
