(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_chats_page_tsx_c03c6700._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_chats_page_tsx_c03c6700._.js",
  "chunks": [
    "static/chunks/[root of the server]__028015f7._.js",
    "static/chunks/[next]_internal_font_google_poppins_f4a4c2a0_module_63d7426e.css"
  ],
  "source": "dynamic"
});
