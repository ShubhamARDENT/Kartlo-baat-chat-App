(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_profile_page_tsx_1cd6a0d9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_profile_page_tsx_1cd6a0d9._.js",
  "chunks": [
    "static/chunks/_9319b3c8._.js"
  ],
  "source": "dynamic"
});
